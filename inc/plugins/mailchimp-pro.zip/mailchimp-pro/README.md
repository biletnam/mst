# MailChimp for WordPress Pro

__Stable Version:__ 2.5.6

Not sure how to install this plugin? Take a look at the installation guide linked below. 

Installation Guide: https://mc4wp.com/kb/installation-instructions/
Frequently Asked Questions and other documentation: https://mc4wp.com/kb/

Support email: support@mc4wp.com

Hope you enjoy this plugin!

Danny van Kooten

support@mc4wp.com